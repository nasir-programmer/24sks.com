<?php
// Headings
$_['heading_title']   = 'Usage';
$_['text_openbay']    = 'OpenBay Pro';
$_['text_ebay']       = 'eBay';

// Text
$_['text_usage']      = 'Your account usage';

// Errors
$_['error_ajax_load'] = 'Sorry, could not get a response. Try later.';